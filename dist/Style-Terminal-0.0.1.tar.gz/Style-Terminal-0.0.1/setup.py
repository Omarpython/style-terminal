import setuptools
setuptools.setup(
    name= 'Style-Terminal',
    version= '0.0.1',
    author= 'Omar-Moahmed',
    description="A library that deals with the device, device style, adding commands, and dealing with colors",
    classifiers=[
    "Progtamming Language :: Python :: 3",
    "Operating System :: MacOS::MacOS X",
    "License :: OSI Approved :: MIT License"
    ]
)